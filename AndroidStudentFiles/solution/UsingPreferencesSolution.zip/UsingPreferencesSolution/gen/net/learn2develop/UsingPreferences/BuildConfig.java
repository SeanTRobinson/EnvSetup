/** Automatically generated file. DO NOT MODIFY */
package net.learn2develop.UsingPreferences;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}