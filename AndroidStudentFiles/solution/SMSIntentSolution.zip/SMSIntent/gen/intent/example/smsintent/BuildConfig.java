/** Automatically generated file. DO NOT MODIFY */
package intent.example.smsintent;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}