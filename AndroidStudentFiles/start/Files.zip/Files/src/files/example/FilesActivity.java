package files.example;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import files.example.Files.R;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class FilesActivity extends Activity {
	EditText textBox;
	static final int READ_BLOCK_SIZE = 100;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		// step 1: refer to the editable text box in the view
		
//        InputStream is = this.getResources().openRawResource(R.raw.textfile);
//        BufferedReader br = new BufferedReader(new InputStreamReader(is));
//        String str = null;
//        try {
//            while ((str = br.readLine()) != null) {
//                Toast.makeText(getBaseContext(), 
//                    str, Toast.LENGTH_SHORT).show();
//            }
//            is.close();
//            br.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

	}

	public void onClickSave(View view) {
		String str = textBox.getText().toString();
		try
		{
            // step 14: write to SD Card Storage instead

            // step 2: instantiate a FileOutputStream object using MODE_WORLD_READABLE		
			
            // step 3: instantiate an OutputStreamWriter             

			// step 4: write the string to the file, flush and close

			// step 5: display 'file saved' message

			// step 6: clear the Editable Text field
		}
		// un-comment the catch block as needed
		/* catch (IOException ioe)
		{
			ioe.printStackTrace();
		}*/
		finally {
			//
		}

	}

	public void onClickLoad(View view) {
		try
		{
			// step 15: retrieve from SD Storage instead

			// step 7: instantiate the FileInputStream
			
			// step 8: instatiate the InputStreamReader
            
            // step 9: provide an input buffer

			// step 10: initialize an empty string

			// step 11: write a string builder

			// step 12: set the Editable Text field to the text that has been read

			// step 13: show a successful message

		}
		// un-comment the catch block as needed
		/* catch (IOException ioe) {
			ioe.printStackTrace();
		} */
		finally {
			//
		}
	}

}