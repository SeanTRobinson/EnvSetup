package net.learn2develop.Menus;

import android.app.Activity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MenusActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    
    
    // override public boolean onCreateOptionsMenu(Menu menu)
    	// call super
    	// call createMenu(menu)
    	// return true (in case the event might be handled elsewhere after this)

    
    // write the createMenu function (pass in a Menu parameter)
    	// for each menu item, add a groupID, itemId, order and title text
    	// e.g. MenuItem mnu1 = menu.add(0,1,1,"Home Screen");
    
    	// optional if time: add an icon: {mnu1.setIcon(R.drawable.iconFileName)};

    // override public boolean onOptionsItemSelected (pass in MenuItem parameter)
 
    	// use switch-case based on item.getItemId() to show the chosen item in Toast
    	// remember to return true in all successful matches
   

}