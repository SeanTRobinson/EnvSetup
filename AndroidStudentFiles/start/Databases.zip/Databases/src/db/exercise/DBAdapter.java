package db.exercise;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBAdapter {
	// define values we will use
    static final String KEY_ROWID = "_id";
    static final String KEY_NAME = "name";
    static final String KEY_EMAIL = "email";
    static final String TAG = "DBAdapter";

    static final String DATABASE_NAME = "MyDB";
    static final String DATABASE_TABLE = "contacts";
    static final int DATABASE_VERSION = 2;
    // step 1: write SQL to create the table
    static final String DATABASE_CREATE = "-";

   // final Context context;

    DatabaseHelper DBHelper;
    SQLiteDatabase db;
    // step 2: define a constructor for DBAdapter (set this.context and create an instance of DatabaseHelper)
   
    // step 3: define a static DatabaseHelper class (extends SQLiteOpenHelper)
    private static class DatabaseHelper 
    {
    	// step 4: define the constructor - call super
        DatabaseHelper(Context context)
        {
            
        }

        // step 5: override onCreate()
       
        // step 6: override onUpgrade()
        
    }

    // step 7: method to open the database


    // step 8: method to close the database


    // step 9: method to insert a new contact into the database


    // step 10: method to delete a contact from the database


    // step 11: method to retrieve all contacts from the database


    // step 12: method to retrieve one contact from the database


    // step 13: method to update one record in the database


}
