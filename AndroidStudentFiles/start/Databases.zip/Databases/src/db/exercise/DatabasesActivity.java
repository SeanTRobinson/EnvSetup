package db.exercise;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import db.exercise.Databases.R;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

public class DatabasesActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // step 1: instantiate DBAdapter

        // step 2: add a contact (open(), insertContact() and close())

        // step 3: get all contacts

        // step 4: get one contact
 
        // step 5: update one contact
 
        // step 6: delete a contact
        
    }
}