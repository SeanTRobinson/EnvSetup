/** Automatically generated file. DO NOT MODIFY */
package using_prefs.example;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}