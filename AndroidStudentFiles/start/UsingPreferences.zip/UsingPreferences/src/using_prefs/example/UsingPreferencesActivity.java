package using_prefs.example;

import using_prefs.example.R;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class UsingPreferencesActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}

	public void onClickLoad(View view) {
		// step 1: create an intent called 'AppPreferenceActivity'
		
		// step 2: start the new activity
		
	}

	// step 3: write the onClickDisplay handler to get shared preferences

	// step 4: write the onClickModify handler 

	// step 5: write the DisplayText method


}