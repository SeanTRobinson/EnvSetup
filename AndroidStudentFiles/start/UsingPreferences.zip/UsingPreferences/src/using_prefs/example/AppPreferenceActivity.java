package using_prefs.example;

import using_prefs.example.R;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;

public class AppPreferenceActivity extends PreferenceActivity {
    // step a: override onCreate
	
        // step c: instantiate PreferenceManager
 
        // step d: set the name of the shared preferences file
 

        // step b: load the preferences from an XML file---

   // don't forget to close the method
}

