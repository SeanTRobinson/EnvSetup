/** Automatically generated file. DO NOT MODIFY */
package menu.exercise.Menus;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}