package menu.exercise;

// always check the correct classes have been imported
import menu.exercise.Menus.R;
import android.app.Activity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.View;


public class MenusActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        // step 2: assign an event listener to the new button
 
        // step 1: declare a new button (which will invoke the menu)
        
        
    }
    
    // create a context sensitive menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenuInfo menuInfo)
    {
         super.onCreateContextMenu(menu, view, menuInfo);
         // step 3: call method to actually generate the menu: CreateMenu(menu);
    }
    
    // create an options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        // step 4: call method to actually generate the options menu: CreateMenu(menu);
        return true;
    }
    
    // step 10: respond to menu option choice
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item)
//    {
//         return MenuChoice(item);
//    }
    
    // step 5: Define a menu helper function (called from onCreateOptionsMenu())
 
    	// step 6: set menu qwerty mode (true)
 
        
        // step 7: add menu item: menu.add(groupId, uniqueId, order, "menu label");) 
        
 
        // step 8: optionally set shortcut and icon
      
    	// step 9: add as many menu items as needed
    
// don't forget to close the method

    // step 11: respond to a menu choice being made (called from onOptionsItemSelected())

        // step 12: write a switch...case block based on unique menu item id

        	// sample menu choice response
//            Toast.makeText(this, "You clicked on Item xxxx",
//                Toast.LENGTH_LONG).show();
//            return true;

        // if no id matches, return false

// don't forget to close the method

}