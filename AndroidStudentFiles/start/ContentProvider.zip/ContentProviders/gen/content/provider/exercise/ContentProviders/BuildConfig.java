/** Automatically generated file. DO NOT MODIFY */
package content.provider.exercise.ContentProviders;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}