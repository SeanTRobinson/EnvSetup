package content.provider.exercise;

import content.provider.exercise.ContentProviders.R;
import android.app.Activity;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

// remember to add the listeners to the buttons in the view

public class ContentProvidersActivity extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	// step 5: insert

		// step 6: set the values to be inserted

		// step 7: call the custom content provider, passing in the new item

		// step 8: echo results (toast)

	// step 9: retrieve

		// step 10: retrieve all the items
		
		// step 11: instantiate a cursor

		// step 12: determine if pre or post Honeycomb

		// step 13: output all results (toast)


	// step 14: update 

	// step 15: delete 



}