package net.learn2develop.Networking;

import android.app.Activity;
import android.os.Bundle;

import java.io.IOException;
import java.io.InputStream;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import android.util.Log;

import android.widget.ImageView;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.InputStreamReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element; 
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class NetworkingActivity extends Activity {
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        // step 23: download binary data e.g. http://www.mayoff.com/5-01cablecarDCP01934.jpg
        
      	// step 26: download text

		//---access a Web Service using GET---
		//new AccessWebServiceTask().execute("apple"); 
    }

	// step 1: write a worker method called OpenHttpConnection
   
    	// step 2: set some variables
       
        // step 3: throw an exception if we don't have an HttpURLConnection
            
        // step 4: try
       
        	// step 4: configure HttpURLConnection
                        
            // step 5: check response is HTTP_OK
            
            	// step 6: getInputStream
            	
        // step 7: catch
        
        // step 8: return
           
    // end of OpenHttpConnection worker method 
    
   // Download Binary Data
   //step 9: DownloadImage method
     
	   // step 10: declarations
 
        // step 11: try
  
        	// step 12: OpenHttpConnection
 
            // step 13: BitmapFactory
  
            // step 14: close Http connection
 
        // step 15: catch
  
        // step 16: return the downloaded image
   
    // end of DownloadImage method
        
    // step 17: DownloadImageTask method
    
    	// step 18: doInBackground
    	
    		// step 19: call DownloadImage, passing in the url
    		
    	// step 20: onPostExecute
    	
    		// step 21: find the ImageView
    		
    		// step 22: setImageBitmap
    		
    // end of DownloadImageTask method
  
    // Download Text content
    // step 24: write a worker method called DownloadText
    
    // step 25: DownloadTextTask

   /* 
    private String WordDefinition(String word) {
        InputStream in = null;
        String strDefinition = "";
        try {
            in = OpenHttpConnection(
"http://services.aonaware.com/DictService/DictService.asmx/Define?word=" + word);
            Document doc = null;
            DocumentBuilderFactory dbf = 
                DocumentBuilderFactory.newInstance();
            DocumentBuilder db;            
            try {
                db = dbf.newDocumentBuilder();
                doc = db.parse(in);
            } catch (ParserConfigurationException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }            
            doc.getDocumentElement().normalize(); 
            
            //---retrieve all the <Definition> elements---
            NodeList definitionElements = 
                doc.getElementsByTagName("Definition"); 
            
            //---iterate through each <Definition> elements---
            for (int i = 0; i < definitionElements.getLength(); i++) { 
                Node itemNode = definitionElements.item(i); 
                if (itemNode.getNodeType() == Node.ELEMENT_NODE) 
                {            
                    //---convert the Definition node into an Element---
                    Element definitionElement = (Element) itemNode;
                    
                    //---get all the <WordDefinition> elements under 
                    // the <Definition> element---
                    NodeList wordDefinitionElements = 
                        (definitionElement).getElementsByTagName(
                        "WordDefinition");
                                        
                    strDefinition = "";
                    //---iterate through each <WordDefinition> elements---
                    for (int j = 0; j < wordDefinitionElements.getLength(); j++) {                    
                        //---convert a <WordDefinition> node into an Element---
                        Element wordDefinitionElement = 
                            (Element) wordDefinitionElements.item(j);
                        
                        //---get all the child nodes under the 
                        // <WordDefinition> element---
                        NodeList textNodes = 
                            ((Node) wordDefinitionElement).getChildNodes();
                        
                        strDefinition += 
                            ((Node) textNodes.item(0)).getNodeValue() + ". \n";    
                    }
                    
                } 
            }
        } catch (IOException e1) {
            Log.d("NetworkingActivity", e1.getLocalizedMessage());
        }   
        //---return the definitions of the word---
        return strDefinition;
    }
  */
    /*
	private class AccessWebServiceTask extends AsyncTask<String, Void, String> {
		protected String doInBackground(String... urls) {
			return WordDefinition(urls[0]);
		}
		
		protected void onPostExecute(String result) {
			Toast.makeText(getBaseContext(), result, Toast.LENGTH_LONG).show();
		}
	}
    */

}