package net.learn2develop.Provider;

import android.app.ListActivity;
import android.os.Bundle;

public class ProviderActivity extends ListActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main); 
       // step 1: specify the URI for accessing the built-in Contacts app // step 12 use predefined constant instead

       // step 2: declare an instance of a Cursor

       // step 3 determine if we are running below SDK 11
        
        	// step 4: before Honeycomb, use a managedQuery
            
        	// step 5: else...

        	// step 6: for Honeycomb and later, use a CursorLoader

        // step 7: map the cursor to a view
        
        // step 8: again check if SDK is 11
        
        	// step 9: before Honeycomb
        	
        	// step 10: Honeycomb and later

        // step 11: set the adapter
    }
}